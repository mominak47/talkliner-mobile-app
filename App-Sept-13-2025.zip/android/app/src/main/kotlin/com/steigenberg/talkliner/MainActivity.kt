package com.steigenberg.talkliner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() 