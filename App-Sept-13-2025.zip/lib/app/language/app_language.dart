import 'package:get/get.dart';

class AppLanguage extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
    'en_US': {
      'username_placeholder': 'Type Username',
      'password_placeholder': 'Type Password',
      'username': 'Username',
      'password': 'Password',
      'connect': 'Connect',
      'connecting': 'Connecting..',
      'settings': 'Settings',
      'qr_login': 'QR Login',
      'select_user_or_group_for_ptt_connection': 'Select user or group for\n PTT Connection',
    },
    'fr_FR': {
      'username_placeholder': 'Entrez le nom d\'utilisateur',
      'password_placeholder': 'Entrez le mot de passe',
      'username': 'Nom d\'utilisateur',
      'password': 'Mot de passe',
      'connect': 'Se connecter',
      'connecting': 'Connexion en cours..',
      'settings': 'Paramètres',
      'qr_login': 'Login QR',
    },
  };
}