import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:talkliner/app/controllers/app_settings_controller.dart';
import 'package:talkliner/app/controllers/contacts_controller.dart';
import 'package:talkliner/app/controllers/home_controller.dart';
import 'package:talkliner/app/controllers/livekit_room_controller.dart';
import 'package:talkliner/app/controllers/push_to_talk_controller.dart';
import 'package:talkliner/app/models/user_model.dart';
import 'package:talkliner/app/themes/talkliner_theme_colors.dart';
import 'package:talkliner/app/views/home/screens/contacts/parts/contact_card.dart';

class ContactsScreen extends StatelessWidget {
  const ContactsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final contactsController = Get.find<ContactsController>();
    final pushToTalkController = Get.find<PushToTalkController>();
    final livekitRoomController = Get.find<LivekitRoomController>();
    final appSettingsController = Get.find<AppSettingsController>();
    final homeController = Get.find<HomeController>();


    Widget getMainWidget() {
      return RefreshIndicator(
        color: TalklinerThemeColors.primary500,
        backgroundColor: TalklinerThemeColors.primary025,
        strokeWidth: 2,
        elevation: 4,
        onRefresh: () async => contactsController.refreshContacts(),
        key: contactsController.refreshIndicatorKey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              TabBar(controller: contactsController.tabController, tabs: contactsController.tabs),
              Column(
                children: List.generate(contactsController.contacts.length, (
                  index,
                ) {
                  UserModel user = contactsController.contacts[index];
                  return Column(
                    children: [
                      ContactCard(
                        user: user,
                        onTapIcon:
                            livekitRoomController.isRoomConnecting.value &&
                                    pushToTalkController
                                            .selectedUser
                                            .value
                                            .id ==
                                        user.id
                                ? LucideIcons.loader
                                : LucideIcons.mic,
                        onTapIconColor: Colors.red,
                        onTap: () {
                          if (pushToTalkController.selectedUser.value.id ==
                              user.id) {
                            pushToTalkController.removeUser();
                          } else {
                            pushToTalkController.setUser(user);
                          }
                        },
                        onTapCard: () {},
                        isSelected:
                            pushToTalkController.selectedUser.value.id ==
                            user.id,
                      ),
                      Divider(height: 1, color: TalklinerThemeColors.gray030),
                    ],
                  );
                }),
              ),
              if (appSettingsController.showFloatingPushToTalkButton.value &&
                  homeController.currentIndex.value != 2)
                SizedBox(height: 100),
            ],
          ),
        ),
      );
    }

    return Obx(() => getMainWidget());
  }
}
