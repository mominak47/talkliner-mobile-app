import 'package:get/get.dart';

class HomeController extends GetxController {
  RxInt currentIndex = 1.obs;

  void setCurrentIndex(int index) {
    currentIndex.value = index;
  }
}