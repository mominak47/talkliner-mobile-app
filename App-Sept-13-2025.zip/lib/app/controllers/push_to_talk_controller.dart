import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:talkliner/app/controllers/livekit_room_controller.dart';
import 'package:talkliner/app/models/user_model.dart';
import 'package:talkliner/app/views/home/screens/pushtotalk/widgets/push_to_talk_button.dart';
import 'package:audioplayers/audioplayers.dart';

class PushToTalkController extends GetxController {
  // Selected User
  final Rx<UserModel> selectedUser = UserModel.fromJson({}).obs;
  final LivekitRoomController livekitRoomController = Get.put<LivekitRoomController>(LivekitRoomController());
  final RxBool isPTTActive = false.obs;

  // Audios
  final _audioPlayer = AudioPlayer();



  @override
  void onInit() {
    super.onInit();
    selectedUser.listen((user) {
      if (user.chatId != null && user.chatId!.isNotEmpty) {
        livekitRoomController.connectToRoom(user.chatId!);
      }
    });
  }

  void playAudio(String audioPath, {double volume = 1.0}) {
    try {
      if (_audioPlayer.state == PlayerState.playing) {
        _audioPlayer.stop();
      }
      // Set volume to full
      _audioPlayer.setVolume(volume);
      _audioPlayer.play(AssetSource(audioPath));
    } catch (e) {
      debugPrint("Error playing audio: $e");
    }
  }



  void removeUser() {
    livekitRoomController.disconnectFromRoom();
    selectedUser.value = UserModel.fromJson({});
  }

  void setUser(UserModel user) => selectedUser.value = user;

  void startPTT() {
    isPTTActive.value = true;
    playAudio('audio/connect.mp3', volume: 1.0);
    livekitRoomController.speak();
  }

  void stopPTT() {
    isPTTActive.value = false;
    livekitRoomController.stopSpeaking();
    playAudio('audio/disconnect.mp3', volume: 1.0);
  }

  PushToTalkButtonState getPTTButtonState() {
    if(selectedUser.value.chatId == null || selectedUser.value.chatId!.isEmpty) return PushToTalkButtonState.notSelected;
    if(livekitRoomController.isRoomConnecting.value) return PushToTalkButtonState.connectingRoom;

    return isPTTActive.value ? PushToTalkButtonState.active : PushToTalkButtonState.inactive;
  }
}
