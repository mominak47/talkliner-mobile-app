import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:talkliner/app/models/user_model.dart';
import 'package:talkliner/app/services/api_service.dart';

class ContactsController extends GetxController with GetSingleTickerProviderStateMixin{
  final refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();
  final RxList<UserModel> contacts = <UserModel>[].obs;
  final ApiService apiService = ApiService();

  late TabController tabController;
  final List<Tab> tabs = [
    Tab(text: 'Users'),
    Tab(text: 'Groups'),
  ];

  // Tab bar index
  final RxInt tabBarIndex = 0.obs;



  @override
  void onInit() {
    super.onInit();
    apiService.onInit();
    tabController = TabController(length: 2, vsync: this);
    fetchContacts();
    loadingContacts();
  }

  void loadContacts() => contacts.assignAll(contacts);

  void loadingContacts() => WidgetsBinding.instance.addPostFrameCallback((_) =>refreshIndicatorKey.currentState?.show());

  // Fetch contacts from the API
  Future<void> fetchContacts() async {
    try {
      final response = await apiService.get('/domains/contacts');
      if (response.body['success'] == true) {
        final List<dynamic> contactList = response.body['data']['contacts'] ?? [];
        contacts.assignAll(contactList.map((contact) => UserModel.fromJson(contact)).toList());
      } else {
        debugPrint(response.body['message']);
      }
    } catch (e) {
      debugPrint(e.toString());
    } finally {
      // There is no 'hide' method for RefreshIndicatorState.
      // To hide the indicator, complete the Future returned by onRefresh.
      // So, nothing to do here. The UI will handle hiding after Future completes.
    }
  }

  Future<void> refreshContacts() async => await fetchContacts();

  Widget getTabBarWidget() {
    return TabBar(tabs: [Tab(text: "Contacts")]);
  }
}
