import 'package:get/get.dart';
import 'package:talkliner/app/config/routes.dart';
import 'package:talkliner/app/config/app_config.dart';
import 'package:talkliner/app/controllers/auth_controller.dart';
import 'package:talkliner/app/views/home/home_view.dart';

class SplashController extends GetxController {
  final AuthController authController = Get.find<AuthController>();

  @override
  void onInit() {
    super.onInit();
    Future.delayed(const Duration(milliseconds: AppConfig.splashDelay), () {
      if (authController.isLoggedIn.value) {
        Get.offAll(
          () => HomeView(),
          transition: Transition.fadeIn,
          duration: Duration.zero,
        );
      } else {
        Get.offAllNamed(Routes.login);
      }
    });
  }
}
