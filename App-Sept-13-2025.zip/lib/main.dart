import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:flutter/services.dart';
import 'package:talkliner/app/config/app_bindings.dart';
import 'package:talkliner/app/config/pages.dart';
import 'package:talkliner/app/config/routes.dart';
import 'package:talkliner/app/language/app_language.dart';
import 'package:talkliner/app/themes/app_theme.dart';

Future<void> main() async {
  // Init getstroage
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  // Disable app rotation (lock to portrait)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Talkliner',
      debugShowCheckedModeBanner: false,
      translations: AppLanguage(),
      locale: const Locale('en', 'US'),
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      initialRoute: Routes.splash,
      getPages: Pages.pages,
      initialBinding: AppBindings(),
    );
  }
}
